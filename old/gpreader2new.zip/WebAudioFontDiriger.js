console.log('WebAudioFontDiriger v1.01');
function WebAudioFontDiriger() {
	var AudioContextFunc = window.AudioContext || window.webkitAudioContext;
	this.audioContext = new AudioContextFunc();
	this.player = new WebAudioFontPlayer();
	this.started = false;
	this.currentSongPosition = 0;
	this.nextAudioTime = 0;
	this.aheadAudioTime = 1;
	this.outputs = [];
	
	var me = this;
	setInterval(function () {
		me.queueNext();
	}, 333);
	return this;
}
WebAudioFontDiriger.prototype.start = function () {
	//console.log('start');
	this.nextAudioTime = this.audioContext.currentTime;
	this.started = true;
};
WebAudioFontDiriger.prototype.stop = function () {
	//console.log('start');
	this.started = false;
};
WebAudioFontDiriger.prototype.loadSong = function (song) {
	this.song = song;
	//console.log('loadSong',this.song);
	var done = [];
	this.cacheFont(this.song, done);
	this.cacheFont(this.song, done);
};
WebAudioFontDiriger.prototype.cacheFont = function (song, done) {

	for (var i = 0; i < this.song.channels.length; i++) {
		var channel = this.song.channels[i];
		var output = { //
			gain : this.audioContext.createGain(),
			volume : 0.125
		};
		output.gain.connect(this.audioContext.destination);
		this.outputs.push(output);
		output.cache = [];
		output.channel=channel.id;
		//channel.cache = [];
		//if (channel.bank == 128) {
		if (channel.program == 128) {
			for (var p = 0; p < song.positions.length; p++) {
				var position = song.positions[p];
				//console.log('position', position);
				for (var k = 0; k < position.motifs.length; k++) {
					if (position.motifs[k].channel == channel.id) {

						var motif = this.findMotif(position.motifs[k].motif, song);
						//console.log('motif', motif);
						for (var c = 0; c < motif.chords.length; c++) {
							var chord = motif.chords[c];
							for (var n = 0; n < chord.notes.length; n++) {
								var note = chord.notes[n];
								//console.log(note);
								this.cacheFirstDrum(output,note.key, channel, done);
							}
						}
					}
				}
			}
		} else {
			this.cacheFirstInstrument(output,channel, done);
			//for (var idx = 0; idx < webAudioFontIndex.length; idx++) {
			/*

			 */
			/*if (webAudioFontIndex[idx].midi == channel.program && (!webAudioFontIndex[idx].drum)) {
			channel.cache[0] = {
			key : 0,
			name : webAudioFontIndex[idx].name
			};
			this.startCacheFont(webAudioFontIndex[idx].js, webAudioFontIndex[idx].name);
			}*/
			//}
		}
	}
	//console.log(song);
};
WebAudioFontDiriger.prototype.inlist = function (o, arr) {
	for (var i = 0; i < arr.length; i++) {
		if (o == arr[i]) {
			return true;
		}
	}
	return false;
};
WebAudioFontDiriger.prototype.cacheFirstInstrument = function (output,channel, done) {
	for (var idx = 0; idx < webAudioFontIndex.length; idx++) {
		if (webAudioFontIndex[idx].midi == channel.program && (!webAudioFontIndex[idx].drum)) {
			var o = {
				key : 0,
				name : webAudioFontIndex[idx].name,
				volume:0.125
			};
			output.cache.push(o);
			if (this.inlist(webAudioFontIndex[idx].name, done)) {
				//
			} else {
				this.startCacheFont(webAudioFontIndex[idx].js, webAudioFontIndex[idx].name);
				done.push(webAudioFontIndex[idx].name);
			}
			break;
		}
	}
};
WebAudioFontDiriger.prototype.cacheFirstDrum = function (output,key, channel, done) {
	for (var idx = 0; idx < webAudioFontIndex.length; idx++) {
		if (webAudioFontIndex[idx].midi == key && webAudioFontIndex[idx].drum) {
			var o = {
				key : key,
				name : webAudioFontIndex[idx].name
				,volume:0.5
			};
			output.cache.push(o);
			if (this.inlist(webAudioFontIndex[idx].name, done)) {
				//
			} else {
				this.startCacheFont(webAudioFontIndex[idx].js, webAudioFontIndex[idx].name);
				done.push(webAudioFontIndex[idx].name);
				//console.log('drum',key);
			}
			break;
		}
	}
};
WebAudioFontDiriger.prototype.startCacheFont = function (file, name) {
	if (window[name]) {
		//
	} else {
		var r = document.createElement('script');
		r.setAttribute("type", "text/javascript");
		r.setAttribute("src", 'https://surikov.github.io/webaudiofont/webaudiofont/' + file);
		document.getElementsByTagName("head")[0].appendChild(r);
	}
};
WebAudioFontDiriger.prototype.queueNext = function () {
	//console.log('queueNext',this.started,this.nextAudioTime,this.currentSongPosition,this.audioContext.currentTime);
	if (this.started) {
		if (this.nextAudioTime - this.aheadAudioTime < this.audioContext.currentTime) {
			var position = song.positions[this.currentSongPosition];
			this.queuePosition(this.nextAudioTime, position);
			var duration = this.positionDuration(position);
			this.nextAudioTime = this.nextAudioTime + duration;
			this.currentSongPosition++;
			if (this.currentSongPosition >= this.song.positions.length) {
				this.currentSongPosition = 0;
			}
			//console.log(this.nextAudioTime, this.currentSongPosition);
		}
	}
};
WebAudioFontDiriger.prototype.queuePosition = function (start, position) {
	var len16 = (4 * 60 / position.tempo) / 16;
	for (var i = 0; i < position.motifs.length; i++) {
		var motif = this.findMotif(position.motifs[i].motif, this.song);
		var channel = this.findChannel(position.motifs[i].channel, this.song);
		var output=this.findOutput(channel);
		this.queueMotif(len16, start, motif, channel, this.song,output);
	}
};
WebAudioFontDiriger.prototype.queueMotif = function (len16, start, motif, channel, song,output) {
	//console.log(motif,channel);
	for (var i = 0; i < motif.chords.length; i++) {
		this.queueChord(len16, start, motif.chords[i], channel, song,output);
	}
};
WebAudioFontDiriger.prototype.queueChord = function (len16, start, chord, channel, song,output) {
	var start16 = start + chord.start * len16;
	for (var i = 0; i < chord.notes.length; i++) {
		this.queueNote(len16, start16, chord.notes[i], channel, song,output);
	}
};
WebAudioFontDiriger.prototype.queueNote = function (len16, start, note, channel, song,output) {
	var cached = this.findFontCache(note.key, channel,output);
	if (cached) {
		this.player.queueWaveTable(this.audioContext //
		, this.audioContext.destination //
		, window[cached.name]//cached //window[channel.cache] //piano //
		, start //
		, note.key //
		, note.l6th * len16 //
		, cached.volume //0.125
		);
		//console.log(cached, cached.volume);
	}
};
WebAudioFontDiriger.prototype.findFontCache = function (key, channel,output) {
	//if (channel.cache.length) {
		var v=null;
		for (var i = 0; i < output.cache.length; i++) {
			if (output.cache[i]) {
				//v=window[output.cache[i].name];
				v=output.cache[i];
				if (output.cache[i].key == key) {
					//console.log('found', channel.cache[i].name);
					//return window[channel.cache[i].name];
					break;
				}
			}
		}
		//return window[channel.cache[0].name];
	//} else {
	//	return null;
	//}
	return v;
};
WebAudioFontDiriger.prototype.findPosition = function (n, s) {
	for (var i = 0; i < s.positions.length; i++) {
		if (s.positions[i].order == n) {
			return s.positions[i];
		}
	}
	return null;
};
WebAudioFontDiriger.prototype.findMotif = function (n, s) {
	for (var i = 0; i < s.motifs.length; i++) {
		if (s.motifs[i].id == n) {
			return s.motifs[i];
		}
	}
	return null;
};
WebAudioFontDiriger.prototype.findChannel = function (n, s) {
	for (var i = 0; i < s.channels.length; i++) {
		if (s.channels[i].id == n) {
			return s.channels[i];
		}
	}
	return null;
};
WebAudioFontDiriger.prototype.findOutput = function (c) {
	for (var i = 0; i < this.outputs.length; i++) {
		if (this.outputs[i].channel == c.id) {
			return this.outputs[i];
		}
	}
	return null;
};
WebAudioFontDiriger.prototype.positionDuration = function (p) {
	var N = 4 * 60 / p.tempo;
	var duration = N * p.meter / p.by;
	return duration;
};
