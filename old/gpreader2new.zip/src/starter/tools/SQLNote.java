package starter.tools;

public class SQLNote {
	public int pitch;
	public int length;
	public int string;
	public int fret;
	public boolean palmMute;
	public int _id = MIDITools.id();
	public boolean same(SQLNote other) {
		if (this.pitch == other.pitch && this.length == other.length && this.palmMute == other.palmMute) {
			return true;
		}
		else {
			return false;
		}
	}
}
