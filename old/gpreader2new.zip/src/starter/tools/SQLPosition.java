package starter.tools;

import java.util.Vector;

public class SQLPosition {
	public int _id = MIDITools.id();
	public int meter16;
	public int tempo;
	public int x;
	public int y;
	public Vector<SQLLayer> layers = new Vector<SQLLayer>();
	public boolean existsLike(SQLRiff riff) {
		for (int i = 0; i < this.layers.size(); i++) {
			if (this.layers.get(i).riff.like(riff)) {
				return true;
			}
		}
		//System.out.println(" nop");
		return false;
	}
	public boolean exists(SQLRiff riff) {
		for (int i = 0; i < this.layers.size(); i++) {
			if (this.layers.get(i).riff.same(riff)) {
				return true;
			}
		}
		return false;
	}
	public boolean same(SQLPosition other) {
		if (this.layers.size() != other.layers.size()) {
			return false;
		}
		for (int i = 0; i < this.layers.size(); i++) {
			SQLRiff riff = this.layers.get(i).riff;
			if (!other.exists(riff)) {
				return false;
			}
		}
		return true;
	}
	public boolean like(SQLPosition other) {
		for (int i = 0; i < this.layers.size(); i++) {
			SQLRiff riff = this.layers.get(i).riff;
			//
			if (!other.existsLike(riff)) {
				return false;
			}
		}
		return true;
	}
}
