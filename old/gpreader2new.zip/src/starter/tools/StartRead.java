package starter.tools;

import java.io.*;
import java.util.List;
import java.util.Vector;
import org.herac.tuxguitar.gm.*;
import org.herac.tuxguitar.io.base.*;
import org.herac.tuxguitar.io.gpx.*;
import org.herac.tuxguitar.io.gtp.*;
import org.herac.tuxguitar.io.midi.*;
import org.herac.tuxguitar.player.base.*;
import org.herac.tuxguitar.song.factory.*;
import org.herac.tuxguitar.song.managers.*;
import org.herac.tuxguitar.song.models.*;

public class StartRead {
	public static String version="2.18";
	public static void main(String[] args) {
		
		//System.out.println("start v1.02");
		try {
			//readGP("d:\\projects\\gpreader2\\tabs\\Twinkle Twinkle Little Star.gp5");
			GP2WA.dump(args[0]);
			//GP2WA.dump("d:\\projects\\gpreader2\\tabs\\Ed Sheeran - I See Fire (Pro).gpx");
			//GP2WA.dump("d:\\projects\\gpreader2\\tabs\\test.gp5");
			//GP2WA.dump("d:\\projects\\gpreader2\\tabs\\Game-of-Thrones-Kenny-Serane.gpx");
			//GP2WA.dump("d:\\projects\\gpreader2\\tabs\\Metallica - Master Of Puppets (Pro).gp5");
			//GP2WA.dump("d:\\projects\\gpreader2\\tabs\\Kino.gp5");
			//GP2WA.dump("d:\\projects\\gpreader2\\tabs\\bieber_sorry.gp5");
                        //GP2WA.dump("/home/sss/Desktop/Downloads/iseefire.gp5");
			   //GP2WA.dump("/home/sss/Desktop/Downloads/metallica-master_of_puppets_20.gp5");
			   //GP2WA.dump("/home/sss/Desktop/Downloads/metallica-enter_sandman_13.gp5");
		}
		catch (Exception e) {
			e.printStackTrace();
                        System.out.println("Guitar Pro converter v"+version);
                        System.out.println("usage:");
                        System.out.println("java -jar c:\\folder\\file.gp5");
                        System.out.println("support gp3|4|5|x");
		}
	}
	public static void dump(String filePath) throws Exception {
		System.out.println("load " + filePath);
		String safeFilePath = filePath.replace('\\', '/');
		TGSong tgSong = GPLoader.loadGPSong(safeFilePath);
		dumpTGsong(tgSong);
	}
	public static void dumpTGsong(TGSong tgSong) {
		System.out.println("album:" + flatText(tgSong.getAlbum()));
		System.out.println("artist:" + flatText(tgSong.getArtist()));
		System.out.println("author:" + flatText(tgSong.getAuthor()));
		System.out.println("comments:" + flatText(tgSong.getComments()));
		System.out.println("copyright:" + flatText(tgSong.getCopyright()));
		System.out.println("date:" + flatText(tgSong.getDate()));
		System.out.println("name:" + flatText(tgSong.getName()));
		System.out.println("transcriber:" + flatText(tgSong.getTranscriber()));
		System.out.println("writer: " + flatText(tgSong.getWriter()));
		//System.out.println("tracks: " + tgSong.tracks.size());
		//System.out.println("measureHeaders: " + tgSong.measureHeaders.size());
		//System.out.println("channels: "+tgSong.channels.size());
		Vector<TGLyric> ly = extractTGLyric(tgSong);
		for (int i = 0; i < ly.size(); i++) {
			System.out.println("lyrics:" + ly.get(i).getFrom() + " / " + flatText(ly.get(i).getLyrics()));
		}
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			dumpTGtrack(tgSong, tgSong.tracks.get(i));
		}
		GPMover mover = new GPMover(tgSong);
		int counter = 1;
		while (!mover.finished()) {
			int index = mover.index;
			mover.process();
			if (mover.shouldPlay) {
				TGMeasureHeader tgMeasureHeader = tgSong.measureHeaders.get(index);
				dumpTGmeasure(counter, tgMeasureHeader);
				counter++;
			}
		}
		for (int i = 0; i < tgSong.measureHeaders.size(); i++) {
			dumpTGheader(tgSong, tgSong.measureHeaders.get(i));
		}
	}
	public static Vector<TGLyric> extractTGLyric(TGSong tgSong) {
		Vector<TGLyric> t = new Vector<TGLyric>();
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			TGTrack tgTrack = tgSong.tracks.get(i);
			if (tgTrack.lyrics != null) {
				if (tgTrack.lyrics.getLyrics() != null) {
					if (tgTrack.lyrics.getLyrics().length() > 1) {
						//System.out.print(", lyrics:" + tgTrack.lyrics.getFrom() + " / " + flatText(tgTrack.lyrics.getLyrics()));
						t.add(tgTrack.lyrics);
					}
				}
			}
		}
		return t;
	}
	public static TGChannel findChannel(TGSong tgSong, TGTrack tgTrack) {
		//int n=tgTrack.getChannelId();
		for (int i = 0; i < tgSong.channels.size(); i++) {
			if (tgSong.channels.get(i).getChannelId() == tgTrack.getChannelId()) {
				return tgSong.channels.get(i);
			}
		}
		return tgSong.channels.get(0);
	}
	public static void dumpTGtrack(TGSong tgSong, TGTrack tgTrack) {
		TGChannel tgChannel = findChannel(tgSong, tgTrack);
		System.out.print("channel:" + tgChannel.channelId + ", bank:" + tgChannel.bank + ", program:" + tgChannel.program + ", volume:" + tgChannel.volume);
		System.out.print(", color:" + tgTrack.color.r + "." + tgTrack.color.g + "." + tgTrack.color.g);
		System.out.print(", offset:" + tgTrack.offset);
		System.out.print(", name:" + tgTrack.name);
		/*if (tgTrack.lyrics != null) {
			if (tgTrack.lyrics.getLyrics() != null) {
				if (tgTrack.lyrics.getLyrics().length() > 1) {
					System.out.print(", lyrics:" + tgTrack.lyrics.getFrom() + " / " + flatText(tgTrack.lyrics.getLyrics()));
				}
			}
		}*/
		System.out.println();
		if (tgTrack.strings != null) {
			for (int i = 0; i < tgTrack.strings.size(); i++) {
				System.out.println("	string:" + tgTrack.strings.get(i).number + ", pitch:" + tgTrack.strings.get(i).value);
			}
		}
		/*for(int n=0;n<tgChannel.parameters.size();n++){
			System.out.println("	"+tgChannel.parameters.get(n).getKey()+": "+tgChannel.parameters.get(n).getValue());
		}*/
	}
	public static String flatText(String t) {
		String r = t.replaceAll("\\r", "\\n");
		r = r.replaceAll("\\n\\n", "\\n");
		r = r.replaceAll("\\n", "`");
		return r;
	}
	public static void dumpTGmeasure(int counter, TGMeasureHeader tgMeasureHeader) {
		System.out.print("position " + counter + ", measure number " + tgMeasureHeader.getNumber());
		if (tgMeasureHeader.tripletFeel > 1) {
			System.out.print(", triplet:" + tgMeasureHeader.tripletFeel);
		}
		if (tgMeasureHeader.tempo != null) {
			System.out.print(", tempo:" + tgMeasureHeader.tempo.getValue());
		}
		if (tgMeasureHeader.timeSignature != null) {
			System.out.print(", meter " + tgMeasureHeader.timeSignature.getNumerator() + "/" + tgMeasureHeader.timeSignature.getDenominator().getValue());
		}
		if (tgMeasureHeader.repeatOpen || tgMeasureHeader.repeatAlternative > 0 || tgMeasureHeader.repeatClose > 0) {
			System.out.print(", repeat:" + tgMeasureHeader.repeatOpen + "/" + tgMeasureHeader.repeatAlternative + "/" + tgMeasureHeader.repeatClose);
		}
		if (tgMeasureHeader.marker != null) {
			System.out.print(", marker:" + flatText(tgMeasureHeader.marker.getTitle()));
		}
		System.out.println();
	};
	public static TGMeasure findMeasure(TGSong tgSong, TGMeasureHeader tgMeasureHeader, TGTrack tgTrack) {
		for (int i = 0; i < tgTrack.measures.size(); i++) {
			if (tgTrack.measures.get(i).getHeader() == tgMeasureHeader) {
				return tgTrack.measures.get(i);
			}
		}
		return null;
	}
	public static void dumpTGheader(TGSong tgSong, TGMeasureHeader tgMeasureHeader) {
		System.out.print("header:" + tgMeasureHeader.getNumber());
		System.out.print(", start:" + tgMeasureHeader.start);
		System.out.println();
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			TGTrack tgTrack = tgSong.tracks.get(i);
			TGMeasure tgMeasure = findMeasure(tgSong, tgMeasureHeader, tgTrack);
			if (tgMeasure != null) {
				if (tgMeasure.beats.size() > 0) {
					System.out.print("	" + tgTrack.name);
					System.out.print(" clef:" + tgMeasure.clef + "/" + tgMeasure.keySignature + ", beats:");
					boolean first = true;
					for (int n = 0; n < tgMeasure.beats.size(); n++) {
						TGBeat beat = tgMeasure.beats.get(n);
						if (!first) {
							System.out.print(",");
						}
						else {
							first = false;
						}
						System.out.print(beat.getStart());
						if (beat.chord != null) {
							String st = "";
							for (int k = 0; k < beat.chord.strings.length; k++) {
								st = st + "/" + beat.chord.strings[k];
							}
							System.out.print("{" + beat.chord.name + "/" + beat.chord.firstFret + st + "}");
						}
						if(beat.stroke.direction>0){
							System.out.print("(+)");//+beat.stroke.value+")");
						}else{
							if(beat.stroke.direction<0){
								System.out.print("(-)");//+beat.stroke.value+")");
							}
						}
						System.out.print("[");
						for(int v=0;v<beat.voices.length;v++){
							TGVoice voice=beat.voices[v];
							if(voice.notes.size()>0){
							System.out.print(voice.duration.getValue());
							if(voice.duration.isDotted()){
								System.out.print("*");
							}
							if(voice.duration.isDoubleDotted()){
								System.out.print("*");
							}
							System.out.print("<"+voice.duration.divisionType.enters+"/"+voice.duration.divisionType.times);
							System.out.print("|"+voice.index);
							System.out.print("|"+voice.direction);
							//System.out.print("|"+voice.empty);
							//System.out.print("|"+voice.notes.size());
							System.out.print("=");
							for(int s=0;s<voice.notes.size();s++){
								TGNote note=voice.notes.get(s);
								System.out.print("'"+note.getString());
							}
							System.out.print(">");
							}
						}
						System.out.print("]");
					}
					System.out.println();
				}
			}
		}
	}
	public static void __main(String[] args) {
		System.out.println("start v1.01.01");
		String gpPath = args[0];
		try {
			//gpPath="d:\\projects\\gpreader2\\tabs\\Ac Dc - Back In Black (Pro).gp5";
			//String gpPath="d:\\projects\\gpreader2\\tabs\\Oasis - Half The World Away (Pro).gp4";
			//String gpPath="d:\\projects\\gpreader2\\tabs\\Twinkle Twinkle Little Star.gp5";
			//testReadX("C:\\projects\\notesplayer\\tabs\\Ac Dc - Back In Black (Pro).gp5");
			//testReadX("C:\\projects\\notesplayer\\tabs\\Ac Dc - Back In Black (Pro).gpx");
			//saveMIDI("d:\\projects\\gpreader2\\tabs\\Twinkle Twinkle Little Star.gp5");
			//saveMIDI("d:\\projects\\gpreader2\\tabs\\Ed Sheeran - I See Fire (Pro).gpx"//
			//		, "d:\\projects\\gpreader2\\tabs\\_test.mid");
			//dumpSong("d:\\projects\\gpreader2\\tabs\\Ed Sheeran - I See Fire (Pro).gpx");//Twinkle Twinkle Little Star.gp5");
			//dumpSong("d:\\projects\\gpreader2\\tabs\\Twinkle Twinkle Little Star.gp5");
			//SQLSong sqlSong = loadSQLSong("d:\\projects\\gpreader2\\tabs\\enter_sandman_8.gp3");
			//SQLSong sqlSong = GPLoader.loadSQLSong("d:\\projects\\gpreader2\\tabs\\Metallica - Enter Sandman (Pro).gp4");
			//SQLSong sqlSong=loadSQLSong("d:\\projects\\gpreader2\\tabs\\Twinkle Twinkle Little Star.gp5");
			//saveMolgav("d:\\projects\\gpreader2\\tabs\\Game-of-Thrones-Kenny-Serane.gpx");
			//saveMolgav("d:\\projects\\gpreader2\\tabs\\Ed Sheeran - I See Fire (Pro).gpx");
			//sqlSong.dumpMolgav(MIDITools.predefinedInstruments, MIDITools.predefinedDrums, "d:\\projects\\gpreader2\\tabs\\test.molgav");
			gpPath = gpPath.replace('\\', '/');
			SQLSong sqlSong = GPLoader.loadSQLSong(gpPath);
			sqlSong.dumpMolgav(MIDITools.predefinedInstruments, MIDITools.predefinedDrums, gpPath + ".molgav");
			sqlSong.dumpSQL(gpPath);
		}
		catch (Throwable t) {
			t.printStackTrace();
		}
		System.out.println("done " + gpPath);
	}
	/*static void testReadX(String from) {
		//String from = "C:\\Users\\surikov\\Desktop\\tabs\\16\\pantera\\this_love_6.gpx";
		//InputStream inputStream;
		try {
			
			GPXInputStream tgInputStreamBase = new GPXInputStream();
			InputStream inputStream = new FileInputStream(from);
			BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
			TGFactory tgFactory = new TGFactory();
			tgInputStreamBase.init(tgFactory, bufferedInputStream);
			tgInputStreamBase.isSupportedVersion();
			TGSong tgSong = tgInputStreamBase.readSong();
			System.out.println("tgSong " + tgSong);
			TGSongManager tgSongManager = new TGSongManager();
			MidiSequenceParser midiSequenceParser = new MidiSequenceParser(tgSong, tgSongManager, MidiSequenceParser.DEFAULT_EXPORT_FLAGS);
			System.out.println("midiSequenceParser " + midiSequenceParser + " " + tgSong.countTracks());
			GMChannelRouter gmChannelRouter = new GMChannelRouter();
			File file = new File(from + ".mid");
			FileOutputStream stream = new FileOutputStream(file);
			//OutputStream stream = this.context.getAttribute(OutputStream.class.getName());
			MidiSequenceHandlerImpl midiSequenceHandlerImpl = new MidiSequenceHandlerImpl((tgSong.countTracks() + 1), gmChannelRouter, stream);
			//int trcnt=midiSequenceHandlerImpl.getTracks();
			for(int i=0;i<midiSequenceHandlerImpl.getTracks();i++){
				System.out.println(i+" track " + midiSequenceHandlerImpl.getSequence());
			}
			midiSequenceParser.parse(midiSequenceHandlerImpl);
			//System.out.println("midiSequenceParser "+midiSequenceParser);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
}
