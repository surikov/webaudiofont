package starter.tools;

import java.io.*;
import java.util.List;
import java.util.Vector;
import org.herac.tuxguitar.gm.*;
import org.herac.tuxguitar.io.base.*;
import org.herac.tuxguitar.io.gpx.*;
import org.herac.tuxguitar.io.gtp.*;
import org.herac.tuxguitar.io.midi.*;
import org.herac.tuxguitar.player.base.*;
import org.herac.tuxguitar.song.factory.*;
import org.herac.tuxguitar.song.managers.*;
import org.herac.tuxguitar.song.models.*;
import org.herac.tuxguitar.song.models.effects.*;
import org.herac.tuxguitar.song.models.effects.TGEffectTremoloBar.TremoloBarPoint;
import org.herac.tuxguitar.song.models.effects.*;

public class GP2WA {
	public static void dump(String filePath) throws Exception {
		String safeFilePath = filePath.replace('\\', '/');
		TGSong tgSong = GPLoader.loadGPSong(safeFilePath);
		dumpTGsong(tgSong);
	}
	public static String flatText(String t) {
		String r = t.replaceAll("\\r", "\\n");
		r = r.replaceAll("\\n\\n", "\\n");
		r = r.replaceAll("\\n", "`");
		r = r.replaceAll("'", "\"");
		return "'" + r.trim() + "'";
	}
	public static String shortNum(double d) {
		if (d == (int) d) {
			return "" + (int) d;
		}
		else {
			return "" + d;
		}
	}
	public static double start16FromTime(long start) {
		//int s64 = (int) Math.floor(start/ 240);
		double s16 = start / 240.0;
		return s16;
	}
	public static String flatColor(int r, int g, int b) {
		return "'rgb(" + r + "," + g + "," + b + ")'";
	}
	public static TGMeasure findMeasure(TGSong tgSong, TGMeasureHeader tgMeasureHeader, TGTrack tgTrack) {
		for (int i = 0; i < tgTrack.measures.size(); i++) {
			if (tgTrack.measures.get(i).getHeader() == tgMeasureHeader) {
				return tgTrack.measures.get(i);
			}
		}
		return null;
	}
	public static TGChannel findChannel(TGSong tgSong, TGTrack tgTrack) {
		for (int i = 0; i < tgSong.channels.size(); i++) {
			if (tgSong.channels.get(i).getChannelId() == tgTrack.getChannelId()) {
				return tgSong.channels.get(i);
			}
		}
		return tgSong.channels.get(0);
	}
	public static Vector<TGLyric> extractTGLyric(TGSong tgSong) {
		Vector<TGLyric> t = new Vector<TGLyric>();
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			TGTrack tgTrack = tgSong.tracks.get(i);
			if (tgTrack.lyrics != null) {
				if (tgTrack.lyrics.getLyrics() != null) {
					if (tgTrack.lyrics.getLyrics().length() > 1) {
						//System.out.print(", lyrics:" + tgTrack.lyrics.getFrom() + " / " + flatText(tgTrack.lyrics.getLyrics()));
						t.add(tgTrack.lyrics);
					}
				}
			}
		}
		return t;
	}
	public static void dumpTGsong(TGSong tgSong) {
		System.out.println("var song={version:"+StartRead.version);
		Vector<TGMeasureHeader> queue = new Vector<TGMeasureHeader>();
		dumpSongProperties(tgSong);
		dumpLyrics(tgSong);
		dumpChannels(tgSong);
		dumpPositions(tgSong, queue);
		dumpMotifs(tgSong, queue);
		System.out.println("	};");
	}
	public static void dumpSongProperties(TGSong tgSong) {
		System.out.println("	,album:" + flatText(tgSong.getAlbum()));
		System.out.println("	,artist:" + flatText(tgSong.getArtist()));
		System.out.println("	,author:" + flatText(tgSong.getAuthor()));
		System.out.println("	,comments:" + flatText(tgSong.getComments()));
		System.out.println("	,copyright:" + flatText(tgSong.getCopyright()));
		System.out.println("	,date:" + flatText(tgSong.getDate()));
		System.out.println("	,name:" + flatText(tgSong.getName()));
		System.out.println("	,transcriber:" + flatText(tgSong.getTranscriber()));
		System.out.println("	,writer:" + flatText(tgSong.getWriter()));
	}
	public static void dumpLyrics(TGSong tgSong) {
		System.out.println("	,lyrics:[");
		Vector<TGLyric> ly = extractTGLyric(tgSong);
		boolean first = true;
		for (int i = 0; i < ly.size(); i++) {
			System.out.print("		");
			if (first) {
				first = false;
			}
			else {
				System.out.print(",");
			}
			System.out.println("{start:" + ly.get(i).getFrom() + ",text:" + flatText(ly.get(i).getLyrics()) + "}");
		}
		System.out.println("		]");
	}
	public static void dumpChannels(TGSong tgSong) {
		System.out.println("	,channels:[");
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			dumpTrackChannel(i, tgSong, tgSong.tracks.get(i));
		}
		System.out.println("		]");
	}
	public static void dumpTrackChannel(int order, TGSong tgSong, TGTrack tgTrack) {
		System.out.print("		");
		if (order > 0) {
			System.out.print(",");
		}
		TGChannel tgChannel = findChannel(tgSong, tgTrack);
		System.out.print("{id:" + tgTrack.exportID);
		//System.out.print(", bank:" + tgChannel.bank);
		//System.out.print(", program:" + tgChannel.program);
		if(tgChannel.bank>127){
			System.out.print(", program:128");
		}else{
			System.out.print(", program:" + tgChannel.program);
		}
		System.out.print(", color:" + flatColor(tgTrack.color.r, tgTrack.color.g, tgTrack.color.b));
		System.out.print(", offset:" + tgTrack.offset);
		System.out.print(", track:" + flatText(tgTrack.name));
		System.out.print(", channel:" + flatText(tgChannel.name));
		System.out.print(", volumes:[{position:0,value:" + tgChannel.volume + "}]");
		System.out.print(", string:[");//
		boolean first = true;
		for (int i = 0; i < tgTrack.strings.size(); i++) {
			if (first) {
				first = false;
			}
			else {
				System.out.print(", ");
			}
			System.out.print("{");
			System.out.print("order:" + tgTrack.strings.get(i).number);
			System.out.print(",pitch:" + tgTrack.strings.get(i).value);
			System.out.print("}");
			//System.out.print(",string:" + tgTrack.strings.get(i).number + ", pitch:" + tgTrack.strings.get(i).value);
		}
		System.out.print("]");//
		System.out.println("}");
		/*
		TGChannel tgChannel = findChannel(tgSong, tgTrack);
		System.out.print("channel:" + tgChannel.channelId + ", bank:" + tgChannel.bank + ", program:" + tgChannel.program + ", volume:" + tgChannel.volume);
		System.out.print(", color:" + tgTrack.color.r + "." + tgTrack.color.g + "." + tgTrack.color.g);
		System.out.print(", offset:" + tgTrack.offset);
		System.out.print(", name:" + tgTrack.name);
		System.out.println();
		if (tgTrack.strings != null) {
			for (int i = 0; i < tgTrack.strings.size(); i++) {
				System.out.println("	string:" + tgTrack.strings.get(i).number + ", pitch:" + tgTrack.strings.get(i).value);
			}
		}*/
	}
	public static void dumpPositions(TGSong tgSong, Vector<TGMeasureHeader> queue) {
		System.out.println("	,positions:[");
		GPMover mover = new GPMover(tgSong);
		int counter = 0;
		while (!mover.finished()) {
			int index = mover.index;
			mover.process();
			if (mover.shouldPlay) {
				TGMeasureHeader tgMeasureHeader = tgSong.measureHeaders.get(index);
				queue.add(tgMeasureHeader);
				dumpOnePosition(counter, tgSong, tgMeasureHeader);
				counter++;
			}
			/*if(counter%10==0){
			    System.out.println("");
			        System.out.print("		");
			}*/
		}
		System.out.println("		]");
	}
	public static void dumpOnePosition(int counter, TGSong tgSong, TGMeasureHeader tgMeasureHeader) {
		if (counter > 0) {
			System.out.print("		,");
		}
		else {
			System.out.print("		");
		}
		System.out.print("{");
		System.out.print("order:" + counter);
		//System.out.print( ",motif:" + tgMeasureHeader.getNumber());
		if (tgMeasureHeader.tripletFeel > 1) {
			System.out.print(",triplet:" + tgMeasureHeader.tripletFeel);
		}
		if (tgMeasureHeader.tempo != null) {
			System.out.print(",tempo:" + tgMeasureHeader.tempo.getValue());
		}
		if (tgMeasureHeader.timeSignature != null) {
			System.out.print(",meter:" + tgMeasureHeader.timeSignature.getNumerator());
			System.out.print(",by:" + tgMeasureHeader.timeSignature.getDenominator().getValue());
		}
		boolean mfirst = true;
		System.out.print(",motifs:[");
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			TGTrack tgTrack = tgSong.tracks.get(i);
			TGMeasure tgMeasure = findMeasure(tgSong, tgMeasureHeader, tgTrack);
			if (tgMeasure != null) {
				if (mfirst) {
					mfirst = false;
				}
				else {
					System.out.print(",");
				}
				//System.out.print("{motif:"+tgMeasure.exportID+",channel:"+tgTrack.exportID+"}");
				//System.out.print(tgMeasure.exportID);
				System.out.print("{motif:" + tgMeasure.exportID);
				System.out.print(",channel:" + tgTrack.exportID);
				System.out.print(",clef:" + tgMeasure.clef);//CLEF_TREBLE = 1;CLEF_BASS = 2;CLEF_TENOR = 3;CLEF_ALTO = 4;
				System.out.print(",sign:" + tgMeasure.keySignature);
				System.out.print("}");
			}
		}
		System.out.print("]");
		if (tgMeasureHeader.repeatOpen) {
			System.out.print(",open:1");
		}
		if (tgMeasureHeader.repeatClose > 0) {
			System.out.print(",count:" + tgMeasureHeader.repeatClose);
		}
		if (tgMeasureHeader.repeatAlternative > 0) {
			//System.out.print(",alt:"+tgMeasureHeader.repeatAlternative +"=");
			//System.out.print(",repeat:" + tgMeasureHeader.repeatOpen + "/" + tgMeasureHeader.repeatAlternative + "/" + tgMeasureHeader.repeatClose);
			System.out.print(",volta:[");
			boolean first = true;
			if ((tgMeasureHeader.repeatAlternative | 0b00000001) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("1");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b00000010) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("2");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b00000100) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("3");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b00001000) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("4");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b00010000) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("5");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b00100000) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("6");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b01000000) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("7");
			}
			if ((tgMeasureHeader.repeatAlternative | 0b10000000) == tgMeasureHeader.repeatAlternative) {
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				System.out.print("8");
			}
			System.out.print("]");
		}
		if (tgMeasureHeader.marker != null) {
			System.out.print(",marker:" + flatText(tgMeasureHeader.marker.getTitle()));
		}
		System.out.println("}");
	}
	public static void dumpMotifs(TGSong tgSong, Vector<TGMeasureHeader> queue) {
		System.out.print("	,motifs:[");
		boolean first = true;
		for (int n = 0; n < tgSong.measureHeaders.size(); n++) {
			TGMeasureHeader tgMeasureHeader = tgSong.measureHeaders.get(n);
			for (int i = 0; i < tgSong.tracks.size(); i++) {
				TGTrack tgTrack = tgSong.tracks.get(i);
				TGMeasure tgMeasure = findMeasure(tgSong, tgMeasureHeader, tgTrack);
				if (tgMeasure != null) {
					System.out.println("");
					System.out.print("		");
					if (first) {
						first = false;
					}
					else {
						System.out.print(",");
					}
					dumpOneMotif(tgTrack, tgMeasure, queue);
					//System.out.print("{motif:"+tgMeasure.exportID+",channel:"+tgTrack.exportID+"}");
					//System.out.print(tgMeasure.exportID);
					//System.out.print("{motif:"+tgMeasure.exportID+",channel:"+tgTrack.exportID+"}");
				}
			}
		}
		System.out.println("");
		System.out.println("		]");
	}
	public static void dumpOneMotif(TGTrack tgTrack, TGMeasure tgMeasure, Vector<TGMeasureHeader> queue) {
		System.out.print("{");
		System.out.print("id:" + tgMeasure.exportID);
		System.out.print(",chords:[");
		System.out.print("//" + tgMeasure.header.number + "-" + tgTrack.channelId);
		boolean first = true;
		for (int n = 0; n < tgMeasure.beats.size(); n++) {
			TGBeat beat = tgMeasure.beats.get(n);
			if (!emptyBeat(beat)) {
				System.out.println("");
				System.out.print("			");
				if (!first) {
					System.out.print(",");
				}
				else {
					first = false;
				}
				dumpOneChord(beat, tgTrack, tgMeasure, queue);
			}
		}
		System.out.println("");
		System.out.print("			]");
		System.out.print("}");
	}
	public static boolean emptyBeat(TGBeat beat) {
		for (int vIndex = 0; vIndex < beat.countVoices(); vIndex++) {
			TGVoice voice = beat.getVoice(vIndex);
			for (int noteIdx = 0; noteIdx < voice.countNotes(); noteIdx++) {
				TGNote note = voice.getNote(noteIdx);
				if (!note.isTiedNote()) {
					return false;
				}
			}
		}
		return true;
	}
	public static void dumpOneChord(TGBeat beat, TGTrack tgTrack, TGMeasure tgMeasure, Vector<TGMeasureHeader> queue) {
		System.out.print("{");
		System.out.print("start:" + shortNum(start16FromTime(beat.getStart() - tgMeasure.getStart())));
		if (beat.stroke.direction != 0) {
			System.out.print(",stroke:" + beat.stroke.direction);
			System.out.print(",to:" + beat.stroke.value);
		}
		System.out.print(",notes:[");
		//System.out.print(",notes" + duration(beat.getVoice(0).getDuration()) + ":[");
		boolean first = true;
		//int direction=0;
		for (int vIndex = 0; vIndex < beat.countVoices(); vIndex++) {
			TGVoice voice = beat.getVoice(vIndex);
			/*if(voice.direction!=0){
				direction=-1;
				System.out.println("---------------------"+direction);
			}
			*/
			for (int noteIdx = 0; noteIdx < voice.countNotes(); noteIdx++) {
				TGNote note = voice.getNote(noteIdx);
				if (!note.isTiedNote()) {
					if (!first) {
						System.out.print(",");
					}
					else {
						first = false;
					}
					dumpOneNote(tgTrack, voice, note, queue);
				}
			}
		}
		System.out.print("]");
		if (beat.chord != null) {
			System.out.print(",name:" + flatText(beat.chord.name));
		}
		System.out.print("}");
	}
	public static double tiedValues(TGVoice voice, Vector<TGMeasureHeader> queue) {
		boolean found = false;
		int idx = -1;
		for (int i = 0; i < queue.size(); i++) {
			TGMeasureHeader tgMeasureHeader = queue.get(i);
			if (!found) {
				if (voice.beat.measure.header == tgMeasureHeader) {
					found = true;
					idx = i;
				}
			}
			if (found) {
				long start = voice.beat.start;
				if (idx > i) {
					start = -1;
				}
				for (int b = 0; b < voice.beat.measure.beats.size(); b++) {
					TGBeat beat = voice.beat.measure.beats.get(b);
					if (beat.start > start) {
						for (int v = 0; v < beat.voices.length; v++) {
							TGVoice tgVoice = beat.voices[v];
							if (tgVoice.notes.size() > 0) {
								TGNote note = tgVoice.notes.get(0);
								if (note.isTiedNote()) {
									double duration16 = 16.0 / tgVoice.duration.getValue();
									duration16=duration16+tiedValues(tgVoice,queue);
									return duration16;
								}
								else {
									return 0;
								}
							}
						}
					}
				}
			}
		}
		return 0;
	}
	public static void dumpOneNote(TGTrack tgTrack, TGVoice voice, TGNote note, Vector<TGMeasureHeader> queue) {
		System.out.print("{");
		System.out.print("key:" + pitch(tgTrack, note));
		System.out.print(",l6th:" + duration(voice.getDuration(),tiedValues(voice, queue)));
		//System.out.print(" +" + tiedValues(voice, queue));
		System.out.print(",string:" + note.string);
		dumpNoteFx(note);
		System.out.print("}");
	}
	public static void dumpNoteFx(TGNote note) {
		boolean first;
		if (note.getEffect().vibrato) {
			System.out.print(",vibrato:1");
		}
		if (note.getEffect().deadNote) {
			System.out.print(",deadNote:1");
		}
		if (note.getEffect().slide) {
			System.out.print(",slide:1");
		}
		if (note.getEffect().hammer) {
			System.out.print(",hammer:1");
		}
		if (note.getEffect().ghostNote) {
			System.out.print(",ghostNote:1");
		}
		if (note.getEffect().accentuatedNote) {
			System.out.print(",accentuatedNote:1");
		}
		if (note.getEffect().heavyAccentuatedNote) {
			System.out.print(",heavyAccentuatedNote:1");
		}
		if (note.getEffect().isPalmMute()) {
			System.out.print(",palmMute:1");
		}
		if (note.getEffect().staccato) {
			System.out.print(",staccato:1");
		}
		if (note.getEffect().tapping) {
			System.out.print(",tapping:1");
		}
		if (note.getEffect().slapping) {
			System.out.print(",slapping:1");
		}
		if (note.getEffect().popping) {
			System.out.print(",popping:1");
		}
		if (note.getEffect().fadeIn) {
			System.out.print(",fadeIn:1");
		}
		if (note.getEffect().letRing) {
			System.out.print(",letRing:1");
		}
		if (note.getEffect().bend != null) {
			System.out.print(",bend:[");
			first = true;
			for (int i = 0; i < note.getEffect().bend.points.size(); i++) {
				TGEffectBend.BendPoint point = note.getEffect().bend.points.get(i);
				if (first) {
					first = false;
				}
				else {
					System.out.print(",");
				}
				System.out.print("{");
				System.out.print("at:" + point.position);
				System.out.print(",to:" + point.value);
				System.out.print("}");
			}
			System.out.print("]");
		}
		if (note.getEffect().tremoloBar != null) {
			System.out.print(",tremoloBar:[");
			first = true;
			List<TremoloBarPoint> points = note.getEffect().tremoloBar.points;
			for (int i = 0; i < points.size(); i++) {
				TremoloBarPoint point = points.get(i);
				if (first) {
					first = false;
				}
				else {
					System.out.print(",");
				}
				System.out.print("{");
				System.out.print("at:" + point.position);
				System.out.print(",to:" + point.value);
				System.out.print("}");
			}
			System.out.print("]");
		}
		if (note.getEffect().harmonic != null) {
			//System.out.print(",harmonic:{type:"+note.getEffect().harmonic.type+",data:"+note.getEffect().harmonic.data+"}");
			System.out.print(",harmonic:{type:");
			int type = note.getEffect().harmonic.type;
			if (type == TGEffectHarmonic.TYPE_NATURAL) {
				System.out.print("'natural'");//none
			}
			else {
				if (type == TGEffectHarmonic.TYPE_ARTIFICIAL) {
					System.out.print("'artificial'");//12,9,5,7,4,3
				}
				else {
					if (type == TGEffectHarmonic.TYPE_TAPPED) {
						System.out.print("'tapped'");//12,9,5,7,4,3
					}
					else {
						if (type == TGEffectHarmonic.TYPE_PINCH) {
							System.out.print("'pinch'");//12,9,5,7,4,3
						}
						else {
							System.out.print("'semi'");//12,9,5,7,4,3
						}
					}
				}
			}
			System.out.print(",by:" + note.getEffect().harmonic.data);
			System.out.print("}");
			/*
			public static final int NATURAL_FREQUENCIES[][] = {
				{12, 12}, //AH12 (+12 frets)
				{9 , 28}, //AH9 (+28 frets)
				{5 , 24}, //AH5 (+24 frets)
				{7 , 19}, //AH7 (+19 frets)
				{4 , 28}, //AH4 (+28 frets)
				{3 , 31}  //AH3 (+31 frets)
			};
			*/
		}
		if (note.getEffect().grace != null) {
			System.out.print(",grace:{");
			System.out.print("fret:" + note.getEffect().grace.fret);
			System.out.print(",duration:" + note.getEffect().grace.duration);
			System.out.print(",dynamic:" + note.getEffect().grace.dynamic);
			System.out.print(",transition:" + note.getEffect().grace.transition);
			System.out.print(",on:" + note.getEffect().grace.onBeat);
			System.out.print(",dead:" + note.getEffect().grace.dead);
			System.out.print("}");
		}
		if (note.getEffect().trill != null) {
			System.out.print(",trill:{");
			System.out.print("fret:" + note.getEffect().trill.fret);
			System.out.print(",duration:" + duration(note.getEffect().trill.duration,0));
			System.out.print("}");
		}
		if (note.getEffect().tremoloPicking != null) {
			System.out.print(",tremoloPicking:" + duration(note.getEffect().tremoloPicking.duration,0));
		}
	}
	public static int pitch(TGTrack tgTrack, TGNote note) {
		int transpose = 0;
		int key = (transpose + tgTrack.getOffset() + note.getValue() //
		+ ((TGString) tgTrack.getStrings().get(note.getString() - 1)).getValue());
		return key;
	}
	public static String duration(TGDuration d,double tied16) {//TGVoice voice) {
		//int duration16 = 16 / voice.getDuration().getValue();
		double duration16 = 16.0 / d.getValue();
		//System.out.println("==================d"+d.doubleDotted);
		if (d.doubleDotted) {
			duration16 = 1.75 * (16.0 / d.getValue());
			//System.out.println("==================d");
		}
		else {
			if (d.dotted) {
				duration16 = 1.5 * (16.0 / d.getValue());
				//System.out.println("----------------D");
			}
		}
		if (duration16 <= 0) {
			duration16 = 1;
		}
		duration16=duration16+tied16;
		//System.out.println(">"+duration16+"/"+d.getValue()+"<");
		return shortNum(duration16);
	}
}
