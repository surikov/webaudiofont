package starter.tools;

import java.util.Vector;

public class SQLChord {
	public int _id = MIDITools.id();
	public int step16;
	public Vector<SQLNote> notes = new Vector<SQLNote>();
	public boolean exists(SQLNote note) {
		for (int i = 0; i < this.notes.size(); i++) {
			if (this.notes.get(i).same(note)) {
				return true;
			}
		}
		return false;
	}
	public boolean same(SQLChord other) {
		if (this.notes.size() != other.notes.size()) {
			return false;
		}
		for (int i = 0; i < this.notes.size(); i++) {
			if (!other.exists(this.notes.get(i))) {
				return false;
			}
		}
		return true;
	}
}
