package starter.tools;

import java.io.PrintWriter;
import java.util.Vector;

public class SQLSong {
	public int _id = MIDITools.id();
	public Vector<SQLRiff> riffs = new Vector<SQLRiff>();
	public Vector<SQLPosition> positions = new Vector<SQLPosition>();
	public Vector<SQLChannel> channels = new Vector<SQLChannel>();
	public SQLPosition findFirstRiffPositipon(SQLRiff r) {
		SQLPosition p = null;
		for (int fp = 0; fp < positions.size(); fp++) {
			SQLPosition tp = positions.get(fp);
			for (int fr = 0; fr < tp.layers.size(); fr++) {
				if (tp.layers.get(fr).riff == r) {
					p = tp;
					break;
				}
			}
		}
		return p;
	}
	public SQLChannel findFirstRiffChannel(SQLRiff r) {
		SQLChannel c = null;
		for (int fp = 0; fp < positions.size(); fp++) {
			SQLPosition tp = positions.get(fp);
			for (int fr = 0; fr < tp.layers.size(); fr++) {
				if (tp.layers.get(fr).riff == r) {
					c = tp.layers.get(fr).channel;
					break;
				}
			}
		}
		return c;
	}
	public void dumpSQL(String filename) {
		StringBuilder out = new StringBuilder();
		String sql = "insert into songs (id,filename) values ("//
				+ _id //
				+ ", '" + filename + "'"//
				+ ");";
		//System.out.println(sql);
		out.append("\n" + sql);
		for (int i = 0; i < this.positions.size(); i++) {
			SQLPosition p = this.positions.get(i);
			sql = "insert into positions (id,song_id,x,y,tempo,meter) values ("//
					+ p._id//
					+ ", " + this._id//
					+ ", " + p.x//
					+ ", " + p.y//
					+ ", " + p.tempo//
					+ ", " + p.meter16//
					+ ");";
			//System.out.println(sql);
			out.append("\n" + sql);
			for (int n = 0; n < p.layers.size(); n++) {
				SQLLayer l = p.layers.get(n);
				sql = "insert into positionriff (id,position_id,riff_id,channel_id) values ("//
						+ MIDITools.id()//
						+ ", " + p._id//
						+ ", " + l.riff._id//
						+ ", " + l.channel._id//
						+ ");";
				//System.out.println(sql);
				out.append("\n" + sql);
			}
		}
		for (int i = 0; i < this.channels.size(); i++) {
			SQLChannel c = this.channels.get(i);
			sql = "insert into channels (id,song_id,midi,sortorder) values ("//
					+ c._id//
					+ ", " + this._id//
					+ ", " + c.midi//
					+ ", " + c.order//
					+ ");";
			//System.out.println(sql);
			out.append("\n" + sql);
			for (int n = 0; n < c.strings.length; n++) {
				sql = "insert into channelstrings (id,channel_id,pitch,sortorder) values ("//
						+ MIDITools.id()//
						+ ", " + c._id//
						+ ", " + c.strings[n]//
						+ ", " + n//
						+ ");";
				//System.out.println(sql);
				out.append("\n" + sql);
			}
		}
		for (int i = 0; i < this.riffs.size(); i++) {
			SQLRiff r = this.riffs.get(i);
			sql = "insert into riffs (id,song_id,meter) values ("//
					+ r._id//
					+ ", " + this._id//
					+ ", " + r.meter16//
					+ ");";
			//System.out.println(sql);
			out.append("\n" + sql);
			for (int b = 0; b < r.chords.size(); b++) {
				SQLChord chord = r.chords.get(b);
				sql = "insert into chords (id,riff_id,step16) values ("//
						+ chord._id//
						+ ", " + r._id//
						+ ", " + chord.step16//
						+ ");";
				//System.out.println(sql);
				out.append("\n" + sql);
				for (int n = 0; n < chord.notes.size(); n++) {
					SQLNote note = chord.notes.get(n);
					sql = "insert into notes (id,chord_id,pitch,len16,fret,stringpitch,palmmute) values ("//
							+ note._id//
							+ ", " + chord._id//
							+ ", " + note.pitch//
							+ ", " + note.length//
							+ ", " + note.fret//
							+ ", " + note.string//
							+ ", " + (note.palmMute ? "1" : "0")//
							+ ");";
					//System.out.println(sql);
					out.append("\n" + sql);
				}
			}
		}
		saveTextFile(out.toString(), filename + ".sql");
	}
	public void dumpMolgav(String[] predefinedInstruments, String[] predefinedDrums, String fileName) {
		String comma = "";
		StringBuilder out = new StringBuilder();
		String palmMutePath = "http://molgav.nn.ru/sf/instruments/029/Sss/046_028-028_60_-2700_8-51737_44100";
		int meter = 1;
		int tempo = 0;
		for (int i = 0; i < positions.size(); i++) {
			if (positions.get(i).meter16 > meter) {
				meter = positions.get(i).meter16;
			}
			if (positions.get(i).tempo > meter) {
				if (positions.get(i).tempo > 40) {
					tempo = 80;
				}
				if (positions.get(i).tempo > 80) {
					tempo = 100;
				}
				if (positions.get(i).tempo > 100) {
					tempo = 120;
				}
				if (positions.get(i).tempo > 120) {
					tempo = 140;
				}
				if (positions.get(i).tempo > 140) {
					tempo = 160;
				}
				if (positions.get(i).tempo > 160) {
					tempo = 180;
				}
				if (positions.get(i).tempo > 180) {
					tempo = 200;
				}
				if (positions.get(i).tempo > 200) {
					tempo = 240;
				}
			}
		}
		out.append("{");
		out.append("	\"id\": " + (int) (Math.random() * 100000));
		out.append("	,\"tempo\": " + tempo);
		out.append("	,\"meter\": " + meter);
		out.append("	,\"samples\": [");
		comma = "";
		for (int i = 0; i < this.channels.size(); i++) {
			SQLChannel c = this.channels.get(i);
			if (c.midi > -1) {
				out.append("		" + comma + "{");
				out.append("		\"id\": " + (1000000 + i * 100000 + c.midi));
				out.append("		,\"midi\": " + c.midi);
				out.append("		,\"volume\": 0.5");
				out.append("		,\"isDrum\": false");
				out.append("		,\"path\": \"" + predefinedInstruments[c.midi] + "\"");
				out.append("		}");
			}
			comma = ",";
		}
		for (int i = 35; i <= 81; i++) {
			String volume = "1.0";
			if (i == 46) {
				volume = "0.25";
			}
			out.append("		" + comma + "{");
			out.append("		\"id\": " + (20000 + i));
			out.append("		,\"midi\": " + i);
			out.append("		,\"volume\": " + volume);
			out.append("		,\"isDrum\": true");
			out.append("		,\"path\": \"" + predefinedDrums[i] + "\"");
			out.append("		}");
			comma = ",";
		}
		out.append("		" + comma + "{");
		out.append("		\"id\": " + 3000029);
		out.append("		,\"midi\": " + 29);
		out.append("		,\"volume\": 0.7");
		out.append("		,\"isDrum\": false");
		out.append("		,\"path\": \"" + palmMutePath + "\"");
		out.append("		}");
		out.append("	]");
		out.append("	,\"riffs\": [");
		comma = "";
		for (int i = 0; i < this.riffs.size(); i++) {
			SQLRiff r = this.riffs.get(i);
			int m16 = 64;
			SQLPosition p = findFirstRiffPositipon(r);
			if (p != null) {
				m16 = p.meter16;
			}
			out.append("		" + comma + "{");
			out.append("		\"id\": \"" + r._id + "\"");
			out.append("		,\"comment\": \"\"");
			out.append("		,\"beat\": [");
			SQLChannel ch = findFirstRiffChannel(r);
			if (ch != null) {
				if (ch.midi < 0) {
					SQLChord[] steps = new SQLChord[m16];
					for (int ss = 0; ss < steps.length; ss++) {
						steps[ss] = new SQLChord();
						for (int s = 0; s < r.chords.size(); s++) {
							SQLChord chord = r.chords.get(s);
							if (chord.step16 == ss) {
								steps[ss] = chord;
								break;
							}
						}
					}
					String stch = "";
					for (int s = 0; s < steps.length; s++) {
						SQLChord chord = steps[s];
						out.append("" + stch + "[");
						String nocm = "";
						for (int n = 0; n < chord.notes.size(); n++) {
							SQLNote note = chord.notes.get(n);
							out.append(nocm + "{\"id\":\"" + ((int) (Math.random() * 100000)) + "\",\"sampleId\":\"" + (20000 + note.pitch) + "\"}");
							nocm = ",";
						}
						out.append("]");
						stch = ",";
					}
				}
			}
			out.append("			]");
			out.append("		,\"tunes\": [");
			if (ch != null)
				if (ch.midi > -1) {
					StringBuilder palmMute = new StringBuilder();
					palmMute.append("			,{" + "\n");
					palmMute.append("			\"id\": \"3" + r._id + "\"" + "\n");
					palmMute.append("			,\"sampleId\": " + 3000029 + "\n");
					out.append("			{" + "\n");
					out.append("			\"id\": \"" + r._id + "\"" + "\n");
					out.append("			,\"sampleId\": " + (1000000 + ch.order * 100000 + ch.midi) + "\n");
					SQLChord[] steps = new SQLChord[m16];
					for (int ss = 0; ss < steps.length; ss++) {
						steps[ss] = new SQLChord();
						for (int s = 0; s < r.chords.size(); s++) {
							SQLChord chord = r.chords.get(s);
							if (chord.step16 == ss) {
								steps[ss] = chord;
								break;
							}
						}
					}
					out.append("			,\"steps\": [");
					palmMute.append("			,\"steps\": [");
					String stch = "";
					for (int s = 0; s < steps.length; s++) {
						SQLChord chord = steps[s];
						out.append("" + stch + "[");
						palmMute.append("" + stch + "[");
						String palmComma = "";
						String noteComma = "";
						for (int n = 0; n < chord.notes.size(); n++) {
							SQLNote note = chord.notes.get(n);
							if (note.palmMute) {
								palmMute.append(palmComma + "{\"id\":\"" + (note._id) + "\",\"pitch\":" + note.pitch + ", \"length\":" + note.length + ", \"shift\":0}");
								palmComma = ",";
							}
							else {
								out.append(noteComma + "{\"id\":\"" + (note._id) + "\",\"pitch\":" + note.pitch + ", \"length\":" + note.length + ", \"shift\":0}");
								noteComma = ",";
							}
							//nocm = ";";
						}
						out.append("]");
						palmMute.append("]");
						stch = ",";
					}
					out.append("]");
					out.append("			}");
					palmMute.append("]" + "\n");
					palmMute.append("			}" + "\n");
					out.append(palmMute.toString());
				}
			out.append("			]");
			out.append("		}");
			comma = ",";
		}
		out.append("	]");
		out.append("	,\"positions\": [");
		comma = "";
		for (int i = 0; i < this.positions.size(); i++) {
			SQLPosition p = this.positions.get(i);
			//System.out.println(i+"/"+p.x);
			out.append("		" + comma + "{");
			out.append("		\"id\": " + (p.x));
			out.append("		,\"left\": " + p.x);
			out.append("		,\"length\": " + p.meter16);
			out.append("		,\"top\": " + p.y);
			out.append("		,\"riffIds\": [");
			String cm = "";
			/*for (int c = 0; c < this.channels.size(); c++) {
				SQLChannel channel = this.channels.get(c);
				System.out.print(cm + "\"" + (100000 + 10000 * channel.order + p.x) + "\"");
				cm = ",";
			}*/
			for (int c = 0; c < p.layers.size(); c++) {
				SQLRiff riff = p.layers.get(c).riff;
				out.append(cm + "\"" + (riff._id) + "\"");
				cm = ",";
			}
			out.append("]");
			out.append("		}");
			comma = ",";
		}
		out.append("	]");
		out.append("}");
		saveTextFile(out.toString(), fileName);
	}
	public static void saveTextFile(String what, String to) {
		try {
			PrintWriter out = new PrintWriter(to);
			out.println(what);
			out.flush();
			out.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	void replaceRiff(SQLRiff from, SQLRiff to) {
		for (int i = 0; i < positions.size(); i++) {
			SQLPosition p = positions.get(i);
			for (int r = 0; r < p.layers.size(); r++) {
				if (p.layers.get(r).riff == from) {
					p.layers.get(r).riff = to;
				}
			}
		}
	}
}
