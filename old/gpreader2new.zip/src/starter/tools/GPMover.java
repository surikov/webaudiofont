package starter.tools;

import org.herac.tuxguitar.song.models.TGDuration;
import org.herac.tuxguitar.song.models.TGMeasureHeader;
import org.herac.tuxguitar.song.models.TGSong;

public class GPMover {
	TGSong song;
	int index = 0;
	int sHeader = -1;
	int eHeader = -1;
	int count = 0;//tgSong.countMeasureHeaders();
	boolean shouldPlay = true;
	boolean repeatOpen = true;
	int repeatAlternative = 0;
	int lastIndex = -1;
	long repeatStart = TGDuration.QUARTER_TIME;
	long repeatEnd = 0;
	long repeatMove = 0;
	int repeatStartIndex = 0;
	int repeatNumber = 0;
	TGMeasureHeader header;// = tgSong.getMeasureHeader(index);
	public GPMover(TGSong tgSong) {
		this.song = tgSong;
		header = tgSong.getMeasureHeader(index);
		this.count = song.countMeasureHeaders();
	}
	public boolean finished() {
		return (this.index >= this.count);
	}
	public void process() {
		TGMeasureHeader header = this.song.getMeasureHeader(this.index);
		//Verifica si el compas esta dentro del rango.
		if ((this.sHeader != -1 && header.getNumber() < this.sHeader) || (this.eHeader != -1 && header.getNumber() > this.eHeader)) {
			this.shouldPlay = false;
			this.index++;
			return;
		}
		//Abro repeticion siempre para el primer compas.
		if ((this.sHeader != -1 && header.getNumber() == this.sHeader) || header.getNumber() == 1) {
			this.repeatStartIndex = this.index;
			this.repeatStart = header.getStart();
			this.repeatOpen = true;
		}
		//Por defecto el compas deberia sonar
		this.shouldPlay = true;
		//En caso de existir una repeticion nueva,
		//guardo el indice de el compas donde empieza una repeticion
		if (header.isRepeatOpen()) {
			this.repeatStartIndex = this.index;
			this.repeatStart = header.getStart();
			this.repeatOpen = true;
			//Si es la primer vez que paso por este compas
			//Pongo numero de repeticion y final alternativo en cero
			if (this.index > this.lastIndex) {
				this.repeatNumber = 0;
				this.repeatAlternative = 0;
			}
		}
		else {
			//verifico si hay un final alternativo abierto
			if (this.repeatAlternative == 0) {
				this.repeatAlternative = header.getRepeatAlternative();
			}
			//Si estoy en un final alternativo.
			//el compas solo puede sonar si el numero de repeticion coincide con el numero de final alternativo.
			if (this.repeatOpen && (this.repeatAlternative > 0) && ((this.repeatAlternative & (1 << (this.repeatNumber))) == 0)) {
				this.repeatMove -= header.getLength();
				if (header.getRepeatClose() > 0) {
					this.repeatAlternative = 0;
				}
				this.shouldPlay = false;
				this.index++;
				return;
			}
		}
		//antes de ejecutar una posible repeticion
		//guardo el indice del ultimo compas tocado 
		this.lastIndex = Math.max(this.lastIndex, this.index);
		//si hay una repeticion la hago
		if (this.repeatOpen && header.getRepeatClose() > 0) {
			if (this.repeatNumber < header.getRepeatClose() || (this.repeatAlternative > 0)) {
				this.repeatEnd = header.getStart() + header.getLength();
				this.repeatMove += this.repeatEnd - this.repeatStart;
				this.index = this.repeatStartIndex - 1;
				this.repeatNumber++;
			}
			else {
				this.repeatStart = 0;
				this.repeatNumber = 0;
				this.repeatEnd = 0;
				this.repeatOpen = false;
			}
			this.repeatAlternative = 0;
		}
		this.index++;
	}
}
