package starter.tools;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import org.herac.tuxguitar.gm.GMChannelRouter;
import org.herac.tuxguitar.gm.GMChannelRouterConfigurator;
import org.herac.tuxguitar.io.base.TGInputStreamBase;
import org.herac.tuxguitar.io.gpx.GPXInputStream;
import org.herac.tuxguitar.io.gtp.GP1InputStream;
import org.herac.tuxguitar.io.gtp.GP2InputStream;
import org.herac.tuxguitar.io.gtp.GP3InputStream;
import org.herac.tuxguitar.io.gtp.GP4InputStream;
import org.herac.tuxguitar.io.gtp.GP5InputStream;
import org.herac.tuxguitar.io.gtp.GTPSettings;
import org.herac.tuxguitar.io.midi.MidiSequenceHandlerImpl;
import org.herac.tuxguitar.player.base.MidiSequenceParser;
import org.herac.tuxguitar.song.factory.TGFactory;
import org.herac.tuxguitar.song.managers.TGSongManager;
import org.herac.tuxguitar.song.models.TGBeat;
import org.herac.tuxguitar.song.models.TGChannel;
import org.herac.tuxguitar.song.models.TGMeasure;
import org.herac.tuxguitar.song.models.TGMeasureHeader;
import org.herac.tuxguitar.song.models.TGNote;
import org.herac.tuxguitar.song.models.TGSong;
import org.herac.tuxguitar.song.models.TGString;
import org.herac.tuxguitar.song.models.TGTrack;
import org.herac.tuxguitar.song.models.TGVoice;

public class GPLoader {
	static void saveMIDI(String from) throws Exception {
		System.out.println("saveMIDI from " + from);
		TGSong tgSong = GPLoader.loadGPSong(from);
		//System.out.println("tgSong.measureHeaders.size() " + tgSong.measureHeaders.size());
		OutputStream outputStream = new FileOutputStream(from + ".mid");
		GMChannelRouter gmChannelRouter = new GMChannelRouter();
		GMChannelRouterConfigurator gmChannelRouterConfigurator = new GMChannelRouterConfigurator(gmChannelRouter);
		gmChannelRouterConfigurator.configureRouter(tgSong.getChannels());
		TGSongManager tgSongManager = new TGSongManager();
		MidiSequenceParser parser = new MidiSequenceParser(tgSong, tgSongManager, MidiSequenceParser.DEFAULT_EXPORT_FLAGS);
		MidiSequenceHandlerImpl midiSequenceHandlerImpl = new MidiSequenceHandlerImpl((tgSong.countTracks() + 1), gmChannelRouter, outputStream);
		parser.parse(midiSequenceHandlerImpl);
	}
	static TGInputStreamBase createStream(String path) {
		//GTPInputStream s = null;
		if (path.toUpperCase().endsWith("GP1")) {
			GTPSettings gtpSettings = new GTPSettings();
			GP1InputStream box = new GP1InputStream(gtpSettings);
			return box;
		}
		if (path.toUpperCase().endsWith("GP2")) {
			GTPSettings gtpSettings = new GTPSettings();
			GP2InputStream box = new GP2InputStream(gtpSettings);
			return box;
		}
		if (path.toUpperCase().endsWith("GP3")) {
			GTPSettings gtpSettings = new GTPSettings();
			GP3InputStream box = new GP3InputStream(gtpSettings);
			return box;
		}
		if (path.toUpperCase().endsWith("GP4")) {
			GTPSettings gtpSettings = new GTPSettings();
			GP4InputStream box = new GP4InputStream(gtpSettings);
			return box;
		}
		if (path.toUpperCase().endsWith("GP5")) {
			GTPSettings gtpSettings = new GTPSettings();
			GP5InputStream box = new GP5InputStream(gtpSettings);
			return box;
		}
		if (path.toUpperCase().endsWith("GPX")) {
			GPXInputStream box = new GPXInputStream();
			return box;
		}
		return null;
	}
	static TGSong loadGPSong(String from) throws Exception {
		TGInputStreamBase tgInputStreamBase = createStream(from);
		InputStream inputStream = new FileInputStream(from);
		BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
		TGFactory tgFactory = new TGFactory();
		tgInputStreamBase.init(tgFactory, bufferedInputStream);
		tgInputStreamBase.isSupportedVersion();
		TGSong tgSong = tgInputStreamBase.readSong();
		return tgSong;
	}
	static SQLSong loadSQLSong(String from) throws Exception {
		MIDITools.fillMIDI();
		TGSong tgSong = loadGPSong(from);
		SQLSong sqlSong = new SQLSong();
		TGSongManager tgSongManager = new TGSongManager();
		GPMover mover = new GPMover(tgSong);
		int transpose = 0;
		//int tempo = 120;
		//int meter = 32;
		//String comma = " ";
		//int rn = tgSong.measureHeaders.size() / 2;
		//TGMeasureHeader tgMeasureHeader = tgSong.measureHeaders.get(rn);
		//int nu = tgMeasureHeader.getTimeSignature().getNumerator();
		//int de = tgMeasureHeader.getTimeSignature().getDenominator().getValue();
		//tempo = tgMeasureHeader.getTempo().getValue();
		//meter = 32 * nu / de;
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			SQLChannel sqlChannel = new SQLChannel();
			sqlSong.channels.add(sqlChannel);
			TGTrack tgTrack = tgSong.tracks.get(i);
			if (tgTrack.strings.size() > 0) {
				sqlChannel.strings = new int[tgTrack.strings.size()];
				for (int str = 0; str < tgTrack.strings.size(); str++) {
					//System.out.println(i + ". " + tgTrack.strings.get(str).getValue() + "/" + tgTrack.strings.get(str).getNumber());
					sqlChannel.strings[tgTrack.strings.get(str).getNumber() - 1] = tgTrack.strings.get(str).getValue();
				}
			}
			TGChannel tgChannel = tgSongManager.getChannel(tgSong, tgTrack.getChannelId());
			short midi = tgChannel.getProgram();
			if (tgChannel.isPercussionChannel()) {
				sqlChannel.midi = -1;
			}
			else {
				sqlChannel.midi = midi;
			}
			sqlChannel.order = i;
			/*for (int m = 0; m < tgTrack.countMeasures(); m++) {
				TGMeasure thMeasure = tgTrack.getMeasure(m);
				SQLRiff sqlRiff = new SQLRiff();
				sqlRiff.channel = sqlChannel;
				sqlSong.riffs.add(sqlRiff);
			}*/
		}
		int counter = 0;
		Vector<Integer> tiedString = new Vector<Integer>();
		Vector<Integer> tiedValue = new Vector<Integer>();
		//Vector<Integer> tiedDuration=new Vector<Integer>();
		Vector<Integer> tiedTrack = new Vector<Integer>();
		Vector<SQLNote> tiedNote = new Vector<SQLNote>();
		while (!mover.finished()) {
			int index = mover.index;
			mover.process();
			if (mover.shouldPlay) {
				SQLPosition sqlPosition = new SQLPosition();
				sqlPosition.x = counter;
				counter++;
				sqlSong.positions.add(sqlPosition);
				//System.out.println(index+": "+sqlPosition.x);
				TGMeasureHeader tgMeasureHeader = tgSong.measureHeaders.get(index);
				int nu = tgMeasureHeader.getTimeSignature().getNumerator();
				int de = tgMeasureHeader.getTimeSignature().getDenominator().getValue();
				sqlPosition.tempo = tgMeasureHeader.getTempo().getValue();
				sqlPosition.meter16 = 16 * nu / de;
				//System.out.println(""+sqlPosition.x+". "+sqlPosition.meter16+" "+nu +":"+ de);
				for (int i = 0; i < tgSong.tracks.size(); i++) {
					TGTrack tgTrack = tgSong.tracks.get(i);
					TGMeasure tgMeasure = tgTrack.measures.get(index);
					SQLRiff sqlRiff = new SQLRiff();
					sqlRiff.meter16=sqlPosition.meter16;
					sqlSong.riffs.add(sqlRiff);
					//sqlRiff.channel = sqlSong.channels.get(i);
					
					//sqlRiff.tempPosition = sqlPosition;
					//sqlRiff.tempo = tgMeasureHeader.getTempo().getValue();
					//sqlRiff.meter16 = 16 * nu / de;
					//System.out.println(sqlRiff.tempo);
					//tgMeasure.beats.get(0);
					for (int b = 0; b < tgMeasure.beats.size(); b++) {
						TGBeat beat = tgMeasure.beats.get(b);
						SQLChord sqlChord = new SQLChord();
						sqlChord.step16 = -1;
						int stepStart16 = (int) Math.floor((beat.getStart() - tgMeasure.header.getStart()) / 240);
						//System.out.print("  beat " + b + ":" + stepStart32 + " ");
						for (int vIndex = 0; vIndex < beat.countVoices(); vIndex++) {
							TGVoice voice = beat.getVoice(vIndex);
							int duration16 = 16 / voice.getDuration().getValue();
							for (int noteIdx = 0; noteIdx < voice.countNotes(); noteIdx++) {
								TGNote note = voice.getNote(noteIdx);
								if (!note.isTiedNote()) {
									int key = (transpose + tgTrack.getOffset() + note.getValue() //
									+ ((TGString) tgTrack.getStrings().get(note.getString() - 1)).getValue());
									//System.out.print("/" + key + ":" + duration32);
									SQLNote sqlNote = new SQLNote();
									sqlNote.pitch = key;
									sqlNote.length = duration16;
									sqlChord.step16 = stepStart16;
									if (note.getEffect().isPalmMute()) {
										sqlNote.palmMute = true;
										//System.out.println("palm");
									}
									sqlNote.string = note.getString() - 1;
									sqlNote.fret = note.getValue();
									for (int t = 0; t < tiedNote.size(); t++) {
										if (tiedString.get(tiedNote.size() - t - 1) == note.getString()//
												&& tiedValue.get(tiedValue.size() - t - 1) == note.getValue()//
												&& tiedTrack.get(tiedValue.size() - t - 1) == i//
										) {
											tiedString.set(tiedNote.size() - t - 1, -1);
											break;
										}
									}
									if (!sqlChord.exists(sqlNote)) {
										sqlChord.notes.add(sqlNote);
										tiedString.add(note.getString());
										tiedValue.add(note.getValue());
										tiedTrack.add(i);
										tiedNote.add(sqlNote);
									}
								}
								else {
									//System.out.println("tied " + note.getString() + "/" + note.getValue() + ":" + duration16);
									for (int t = 0; t < tiedNote.size(); t++) {
										if (tiedString.get(tiedNote.size() - t - 1) == note.getString()//
												&& tiedValue.get(tiedValue.size() - t - 1) == note.getValue()//
												&& tiedTrack.get(tiedValue.size() - t - 1) == i//
										) {
											if (tiedNote.get(tiedNote.size() - t - 1).length < 128) {
												tiedNote.get(tiedNote.size() - t - 1).length = tiedNote.get(tiedNote.size() - t - 1).length + duration16;
											}
											break;
										}
									}
								}
							}
						}
						if (sqlChord.step16 > -1) {
							sqlRiff.chords.add(sqlChord);
						}
						//System.out.println("");
					}
					//System.out.println(sqlRiff.tempo+" "+sqlRiff);
					boolean exsts = false;
					for (int dbl = 0; dbl < sqlPosition.layers.size(); dbl++) {
						if (sqlPosition.layers.get(dbl).riff.same(sqlRiff)) {
							exsts = true;
							break;
						}
					}
					if (!exsts) {
						SQLLayer l=new SQLLayer();
						l.riff=sqlRiff;
						l.channel=sqlSong.channels.get(i);
						sqlPosition.layers.add(l);
						//sqlPosition.riffs.add(sqlRiff);
					}
				}
				//counter++;
				//System.out.println(""+sqlPosition.x+"/"+sqlPosition.meter16);
			}
		}
		//sqlSong.dumpMolgav(predefinedInstruments,predefinedDrums);
		//System.out.println("riffs " + sqlSong.riffs.size());
		reduceRiffs(sqlSong);
		//System.out.println("now " + sqlSong.riffs.size());
		splitRows(sqlSong);
		return sqlSong;
	}
	static void splitRows(SQLSong sqlSong) {
		for (int i = 0; i < sqlSong.positions.size() - 1; i++) {
			SQLPosition one = sqlSong.positions.get(i);
			SQLPosition next = sqlSong.positions.get(i + 1);
			//System.out.println(i + ". " + one.like(next));
		}
	}
	static void reduceRiffs(SQLSong sqlSong) {
		for (int i = 0; i < sqlSong.riffs.size(); i++) {
			SQLRiff riff = sqlSong.riffs.get(i);
			for (int n = i + 1; n < sqlSong.riffs.size(); n++) {
				SQLRiff another = sqlSong.riffs.get(n);
				//if (riff.channel.midi == another.channel.midi) {
					if (riff.same(another)) {
						//System.out.println(i + ". " + n);
						sqlSong.replaceRiff( another, riff);
						sqlSong.riffs.remove(n);
						n--;
					}
				//}
			}
		}
	}
	static void dumpSong(String from) throws Exception {
		System.out.println("dumpSong " + from);
		TGSong tgSong = GPLoader.loadGPSong(from);
		TGSongManager tgSongManager = new TGSongManager();
		GPMover mover = new GPMover(tgSong);
		int transpose = 0;
		int nn = 0;
		for (int i = 0; i < tgSong.tracks.size(); i++) {
			TGTrack tgTrack = tgSong.tracks.get(i);
			TGChannel tgChannel = tgSongManager.getChannel(tgSong, tgTrack.getChannelId());
			short midi = tgChannel.getProgram();
			if (tgChannel.isPercussionChannel()) {
				System.out.println("track " + i + ": drums");
			}
			else {
				System.out.println("track " + i + ": " + midi);
			}
		}
		while (!mover.finished()) {
			int index = mover.index;
			mover.process();
			if (mover.shouldPlay) {
				TGMeasureHeader tgMeasureHeader = tgSong.measureHeaders.get(index);
				System.out.println(nn + ". measure " + tgMeasureHeader.getNumber() //
						+ ", meter " + tgMeasureHeader.getTimeSignature().getNumerator()// 
						+ "/" + tgMeasureHeader.getTimeSignature().getDenominator().getValue() //
						+ ", tempo " + tgMeasureHeader.getTempo().getValue());
				for (int i = 0; i < tgSong.tracks.size(); i++) {
					TGTrack track = tgSong.tracks.get(i);
					TGChannel tgChannel = tgSongManager.getChannel(tgSong, track.getChannelId());
					TGMeasure measure = track.measures.get(index);
					System.out.println(" track " + i);
					for (int b = 0; b < measure.beats.size(); b++) {
						TGBeat beat = measure.beats.get(b);
						int stepStart32 = (int) Math.floor((beat.getStart() - measure.header.getStart()) / 120);
						System.out.print("  beat " + b + ":" + stepStart32 + " ");
						for (int vIndex = 0; vIndex < beat.countVoices(); vIndex++) {
							TGVoice voice = beat.getVoice(vIndex);
							int duration32 = 32 / voice.getDuration().getValue();
							for (int noteIdx = 0; noteIdx < voice.countNotes(); noteIdx++) {
								TGNote note = voice.getNote(noteIdx);
								if (!note.isTiedNote()) {
									int key = (transpose + track.getOffset() + note.getValue() + ((TGString) track.getStrings().get(note.getString() - 1)).getValue());
									System.out.print("/" + key + ":" + duration32);
								}
							}
						}
						System.out.println("");
					}
				}
				//System.out.println();
				nn++;
			}
		}
	}
}
