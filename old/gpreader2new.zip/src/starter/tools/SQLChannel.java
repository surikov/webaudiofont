package starter.tools;

public class SQLChannel {
	public int midi;
	public int order;
	int[] strings;
	public int _id = MIDITools.id();
}
