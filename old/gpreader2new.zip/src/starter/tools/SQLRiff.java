package starter.tools;

import java.util.Vector;

public class SQLRiff {
	public int _id = MIDITools.id();
	public Vector<SQLChord> chords = new Vector<SQLChord>();
	public int meter16=0;
	public SQLChord findChord(int step) {
		for (int i = 0; i < chords.size(); i++) {
			SQLChord chord = chords.get(i);
			if (chord.step16 == step) {
				return chord;
			}
		}
		return null;
	}
	public boolean same(SQLRiff other) {
		if (this.chords.size() != other.chords.size()) {
			return false;
		}
		for (int i = 0; i < chords.size(); i++) {
			SQLChord chord = chords.get(i);
			SQLChord another = other.findChord(chord.step16);
			if (another == null) {
				return false;
			}
			if (!chord.same(another)) {
				return false;
			}
		}
		return true;
	}
	public boolean like(SQLRiff other) {
		if(this.chords.size()==0 || other.chords.size()==0){
			return true;
		}
		double counter = 0;
		for (int i = 0; i < this.chords.size(); i++) {
			SQLChord chord = this.chords.get(i);
			SQLChord another = other.findChord(chord.step16);
			if (another != null) {
				if (chord.same(another)) {
					counter++;
				}
			}
		}
		double r=counter / this.chords.size();
		//System.out.println("	"+counter+" / "+this.chords.size()+" = "+r);
		if ( r< 0.99) {
			return false;
		}
		else {
			return true;
		}
	}
}
