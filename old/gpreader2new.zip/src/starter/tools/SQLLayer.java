package starter.tools;

public class SQLLayer {
	public SQLChannel channel;
	public SQLRiff riff;
}
