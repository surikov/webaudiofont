package org.herac.tuxguitar.graphics;

public interface TGColor extends TGResource {
	
	public int getRed();
	
	public int getGreen();
	
	public int getBlue();
}
