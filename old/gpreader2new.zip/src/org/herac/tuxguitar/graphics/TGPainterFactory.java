package org.herac.tuxguitar.graphics;

public interface TGPainterFactory {
	
	public TGPainter createPainter();
	
}
