package org.herac.tuxguitar.graphics;

public interface TGImage extends TGResource,TGPainterFactory {
	
	public float getWidth();
	
	public float getHeight();
}
