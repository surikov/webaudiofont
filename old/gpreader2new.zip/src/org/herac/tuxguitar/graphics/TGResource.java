package org.herac.tuxguitar.graphics;

public interface TGResource {
	
	public void dispose();
	
	public boolean isDisposed();
	
}
