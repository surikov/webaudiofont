package org.herac.tuxguitar.io.midi;

public class MidiFileException extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	public MidiFileException(String message) {
		super(message);
	}
}
