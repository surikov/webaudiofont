package org.herac.tuxguitar.io.midi;

public class MidiPlugin {
	
	public static final String MODULE_ID = "tuxguitar-midi";
	
}
