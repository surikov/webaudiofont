package org.herac.tuxguitar.io.gtp;

public class GTPPlugin {
	
	public static final String MODULE_ID = "tuxguitar-gtp";
	
}
