package org.herac.tuxguitar.io.base;

public interface TGSongStream {
	
	void process() throws TGFileFormatException;
}
