package org.herac.tuxguitar.io.base;


public interface TGLocalFileImporter extends TGRawImporter {
	
	public TGFileFormat getFileFormat();
	
}
