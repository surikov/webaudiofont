package org.herac.tuxguitar.io.base;

public interface TGRawExporter extends TGSongStreamProvider {
	
	public String getExportName();
	
}
