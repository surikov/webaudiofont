package org.herac.tuxguitar.io.base;

public interface TGLocalFileExporter extends TGRawExporter {
	
	public TGFileFormat getFileFormat();
	
}
