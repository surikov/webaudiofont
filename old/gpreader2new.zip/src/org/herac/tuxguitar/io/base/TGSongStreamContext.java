package org.herac.tuxguitar.io.base;

import org.herac.tuxguitar.util.TGAbstractContext;

public class TGSongStreamContext extends TGAbstractContext {
	
	public TGSongStreamContext() {
		super();
	}
}
