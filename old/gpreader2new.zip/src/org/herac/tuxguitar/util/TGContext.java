package org.herac.tuxguitar.util;

public class TGContext extends TGAbstractContext {
	
	public TGContext(){
		super();
	}
}
