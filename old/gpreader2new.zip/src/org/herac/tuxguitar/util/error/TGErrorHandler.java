package org.herac.tuxguitar.util.error;

public interface TGErrorHandler {
	
	public void handleError(Throwable throwable);
	
}
