package org.herac.tuxguitar.util.properties;

public interface TGPropertiesFactory {
	
	public TGProperties createProperties() throws TGPropertiesException;
	
}
