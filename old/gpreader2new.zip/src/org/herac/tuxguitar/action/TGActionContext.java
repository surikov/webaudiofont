package org.herac.tuxguitar.action;

import org.herac.tuxguitar.util.TGAbstractContext;

public abstract class TGActionContext extends TGAbstractContext {
	
	public TGActionContext(){
		super();
	}
}
